﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFkr
{
    public partial class FormAr : Form
    {
        string opf = "";
        string zipPath = "";
        string extractPath = "";
        public FormAr()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog OPF = new OpenFileDialog();
            if (OPF.ShowDialog() == DialogResult.OK)
            {
                opf = OPF.FileName;
                richTextBox1.Text = richTextBox1.Text + opf;
                //  MessageBox.Show(OPF.FileName);
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            Form1 fr1 = new Form1();
            fr1.Show();
            Hide();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            zipPath = opf;
            FolderBrowserDialog FBD = new FolderBrowserDialog();
            if (FBD.ShowDialog() == DialogResult.OK)
            {
                extractPath = FBD.SelectedPath;
                //richTextBox1.Text = richTextBox1.Text + zipPath;
                // MessageBox.Show(FBD.SelectedPath);
            }
            try
            {
                ZipFile.ExtractToDirectory(zipPath, extractPath);
                MessageBox.Show("Файлы разархивированы!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
