﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Compression;

namespace WFkr
{

    public partial class Form2 : Form
    {
        string fbb = "";
        string start = "";
        public static string zip = "";
        string op = "";
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog OPF = new OpenFileDialog();
            if (OPF.ShowDialog() == DialogResult.OK)
            {
                op = OPF.FileName;
                richTextBox1.Text = richTextBox1.Text + op;
                //  MessageBox.Show(OPF.FileName);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            start = op;
            FolderBrowserDialog FBD = new FolderBrowserDialog();
            if (FBD.ShowDialog() == DialogResult.OK)
            {
                fbb = FBD.SelectedPath;
            }
                var form = new FormSelectName();
            if (form.ShowDialog() == DialogResult.OK)
            {
                fbb += @"\" + zip + ".zip";
            }
            richTextBox1.Text = richTextBox1.Text + "\n" + fbb;

            //Process.Start("cmd.exe", "tar.exe -a -c -f " + fbb + " " + op);
            Process p = new Process();
            p.StartInfo.UseShellExecute = false;
            p.StartInfo.FileName = "cmd.exe";
            p.StartInfo.Arguments = "/C" + "tar.exe -a -c -f " + fbb + " " + op;
            p.StartInfo.CreateNoWindow = true;
            p.Start();
            MessageBox.Show("Вы успешно заархивировали файл!");

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 fr1 = new Form1();
            fr1.Show();
            Hide();
        }
    }
}
