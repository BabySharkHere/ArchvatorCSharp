﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFkr
{
    public partial class FormZip : Form
    {
        string fb;
        string startPath = "";
        public static string zipPath = "";
        string str = "";
        //string zipPath = @"C:\Users\Lenovo\Desktop\result.zip";
        public FormZip()
        {
            InitializeComponent();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {


            FolderBrowserDialog FBD = new FolderBrowserDialog();
            if (FBD.ShowDialog() == DialogResult.OK)
            {
                fb = FBD.SelectedPath;
                richTextBox1.Text = richTextBox1.Text + fb;
                // MessageBox.Show(FBD.SelectedPath);
            }

        }


        private void button2_Click(object sender, EventArgs e)
        {
            startPath = fb;

            FolderBrowserDialog FBD = new FolderBrowserDialog();
            if (FBD.ShowDialog() == DialogResult.OK)
            {
                str = FBD.SelectedPath;
                //richTextBox1.Text = richTextBox1.Text + zipPath;
                // MessageBox.Show(FBD.SelectedPath);
            }
            var form = new FormSelectName();
            if(form.ShowDialog() == DialogResult.OK)
            {
                str += @"\" + zipPath + ".zip";    
            }
            richTextBox1.Text = richTextBox1.Text + "\n" + str;
            try
            {
                ZipFile.CreateFromDirectory(startPath, str);
                MessageBox.Show("Вы успешно заархивировали файл!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
          private void button3_Click(object sender, EventArgs e)
        {
            Form1 fr1 = new Form1();
            fr1.Show();
            Hide();
        }
    }
}
